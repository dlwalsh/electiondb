'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _graphql = require('graphql');

var _ResultType = require('./ResultType');

var _ResultType2 = _interopRequireDefault(_ResultType);

var _query = require('../query');

var _query2 = _interopRequireDefault(_query);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var schema = new _graphql.GraphQLSchema({
  query: new _graphql.GraphQLObjectType({
    name: 'RootQueryType',
    arguments: {
      locale: _graphql.GraphQLString
    },
    fields: {
      results: {
        type: new _graphql.GraphQLList(_ResultType2.default),
        args: {
          chamber: {
            type: _graphql.GraphQLString
          },
          electionType: {
            type: _graphql.GraphQLString
          },
          electorateId: {
            type: _graphql.GraphQLString
          },
          parliament: {
            type: _graphql.GraphQLInt
          },
          realm: {
            type: _graphql.GraphQLString
          }
        },
        resolve: function resolve(root, args) {
          return (0, _query2.default)('elections', args);
        }
      }
    }
  })
});

exports.default = schema;