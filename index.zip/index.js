'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.handler = undefined;

var _graphql = require('graphql');

var _schema = require('./schema');

var _schema2 = _interopRequireDefault(_schema);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/* eslint import/prefer-default-export: 0 */
function handler(event, context, callback) {
  (0, _graphql.graphql)(_schema2.default, event.query).then(function (data) {
    callback(null, data);
  }, function (err) {
    callback(err);
  });
}

exports.handler = handler;