'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _graphql = require('graphql');

var _CandidateType = require('./CandidateType');

var _CandidateType2 = _interopRequireDefault(_CandidateType);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var ResultType = new _graphql.GraphQLObjectType({
  name: 'contest',
  fields: {
    electorateId: {
      type: _graphql.GraphQLString
    },
    electorateName: {
      type: _graphql.GraphQLString
    },
    type: {
      type: _graphql.GraphQLString
    },
    realm: {
      type: _graphql.GraphQLString
    },
    region: {
      type: _graphql.GraphQLString
    },
    chamber: {
      type: _graphql.GraphQLString
    },
    parliament: {
      type: _graphql.GraphQLInt
    },
    date: {
      type: _graphql.GraphQLString
    },
    vacancies: {
      type: _graphql.GraphQLInt
    },
    enrolment: {
      type: _graphql.GraphQLInt
    },
    informal: {
      type: _graphql.GraphQLInt
    },
    primary: {
      type: new _graphql.GraphQLList(_CandidateType2.default)
    },
    runoff: {
      type: new _graphql.GraphQLList(_CandidateType2.default)
    }
  }
});

exports.default = ResultType;