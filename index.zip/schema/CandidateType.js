'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _graphql = require('graphql');

var CandidateType = new _graphql.GraphQLObjectType({
  name: 'candidate',
  fields: {
    name: {
      type: _graphql.GraphQLString
    },
    party: {
      type: _graphql.GraphQLString
    },
    votes: {
      type: _graphql.GraphQLInt
    },
    elected: {
      type: _graphql.GraphQLBoolean
    }
  }
});

exports.default = CandidateType;