'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _awsSdk = require('aws-sdk');

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function constructParams(tableName) {
  var fields = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};

  var keys = Object.keys(fields);

  if (keys.length === 0) {
    return {
      TableName: tableName
    };
  }

  var filters = keys.map(function (key) {
    return '#' + key + ' = :' + key;
  });
  var attributeNames = keys.reduce(function (memo, key) {
    return Object.assign(memo, _defineProperty({}, '#' + key, key));
  }, {});
  var attributeValues = keys.reduce(function (memo, key) {
    return Object.assign(memo, _defineProperty({}, ':' + key, fields[key]));
  }, {});

  return {
    TableName: tableName,
    FilterExpression: filters.join(' AND '),
    ExpressionAttributeNames: attributeNames,
    ExpressionAttributeValues: attributeValues
  };
}

function query(tableName) {
  var fields = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};

  var docClient = new _awsSdk.DynamoDB.DocumentClient({ region: 'ap-southeast-2' });
  var params = constructParams(tableName, fields);

  return new Promise(function (resolve, reject) {
    docClient.scan(params, function (err, data) {
      if (err) {
        reject(err);
      } else {
        resolve(data.Items);
      }
    });
  });
}

exports.default = query;